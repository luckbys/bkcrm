import { CustomerManagement } from '@/components/crm/customers';

export const CustomerPage = () => {
  return <CustomerManagement />;
}; 